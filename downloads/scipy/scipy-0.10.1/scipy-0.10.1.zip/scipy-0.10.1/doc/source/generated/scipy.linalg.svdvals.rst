scipy.linalg.svdvals
====================

.. currentmodule:: scipy.linalg

.. autofunction:: svdvals