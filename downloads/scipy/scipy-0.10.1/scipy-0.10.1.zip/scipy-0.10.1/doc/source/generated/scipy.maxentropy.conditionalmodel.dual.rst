scipy.maxentropy.conditionalmodel.dual
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.dual