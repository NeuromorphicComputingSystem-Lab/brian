scipy.integrate.complex_ode.set_initial_value
=============================================

.. currentmodule:: scipy.integrate

.. automethod:: complex_ode.set_initial_value