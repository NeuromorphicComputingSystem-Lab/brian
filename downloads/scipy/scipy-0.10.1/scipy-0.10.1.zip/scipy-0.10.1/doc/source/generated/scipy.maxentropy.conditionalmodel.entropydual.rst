scipy.maxentropy.conditionalmodel.entropydual
=============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.entropydual