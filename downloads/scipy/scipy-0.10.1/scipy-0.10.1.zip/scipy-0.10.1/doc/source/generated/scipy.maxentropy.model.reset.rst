scipy.maxentropy.model.reset
============================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.reset