scipy.maxentropy.bigmodel.reset
===============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.reset