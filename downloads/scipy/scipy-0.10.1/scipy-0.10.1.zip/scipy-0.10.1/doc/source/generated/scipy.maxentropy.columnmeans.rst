scipy.maxentropy.columnmeans
============================

.. currentmodule:: scipy.maxentropy

.. autofunction:: columnmeans