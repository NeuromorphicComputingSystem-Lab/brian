scipy.interpolate.UnivariateSpline.set_smoothing_factor
=======================================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.set_smoothing_factor