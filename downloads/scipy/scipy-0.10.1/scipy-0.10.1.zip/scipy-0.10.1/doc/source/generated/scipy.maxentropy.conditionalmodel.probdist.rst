scipy.maxentropy.conditionalmodel.probdist
==========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.probdist