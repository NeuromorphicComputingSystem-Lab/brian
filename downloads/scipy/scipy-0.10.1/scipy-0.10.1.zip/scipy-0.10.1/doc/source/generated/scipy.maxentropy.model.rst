scipy.maxentropy.model
======================

.. currentmodule:: scipy.maxentropy

.. autoclass:: model

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         model.beginlogging
         model.clearcache
         model.crossentropy
         model.dual
         model.endlogging
         model.entropydual
         model.expectations
         model.fit
         model.grad
         model.log
         model.lognormconst
         model.logparams
         model.logpmf
         model.normconst
         model.pmf
         model.pmf_function
         model.probdist
         model.reset
         model.setcallback
         model.setfeaturesandsamplespace
         model.setparams
         model.setsmooth



   

