scipy.linalg.lu_factor
======================

.. currentmodule:: scipy.linalg

.. autofunction:: lu_factor