scipy.linalg.lu
===============

.. currentmodule:: scipy.linalg

.. autofunction:: lu