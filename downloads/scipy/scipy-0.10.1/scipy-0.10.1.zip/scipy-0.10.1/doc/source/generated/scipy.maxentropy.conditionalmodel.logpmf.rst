scipy.maxentropy.conditionalmodel.logpmf
========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.logpmf