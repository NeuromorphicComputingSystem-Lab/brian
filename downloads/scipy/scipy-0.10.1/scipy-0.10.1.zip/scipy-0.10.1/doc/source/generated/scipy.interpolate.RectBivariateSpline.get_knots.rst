scipy.interpolate.RectBivariateSpline.get_knots
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.get_knots