scipy.maxentropy.basemodel.logparams
====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.logparams