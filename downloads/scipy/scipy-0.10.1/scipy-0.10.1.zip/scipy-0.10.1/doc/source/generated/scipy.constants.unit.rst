scipy.constants.unit
====================

.. currentmodule:: scipy.constants

.. autofunction:: unit