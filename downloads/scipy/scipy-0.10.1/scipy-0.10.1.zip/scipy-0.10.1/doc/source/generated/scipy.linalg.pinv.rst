scipy.linalg.pinv
=================

.. currentmodule:: scipy.linalg

.. autofunction:: pinv