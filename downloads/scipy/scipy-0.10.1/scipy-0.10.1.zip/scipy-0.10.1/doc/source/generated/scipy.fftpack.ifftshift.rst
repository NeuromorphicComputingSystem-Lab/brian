scipy.fftpack.ifftshift
=======================

.. currentmodule:: scipy.fftpack

.. autofunction:: ifftshift