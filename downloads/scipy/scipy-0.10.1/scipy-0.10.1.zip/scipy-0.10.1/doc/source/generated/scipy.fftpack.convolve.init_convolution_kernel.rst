scipy.fftpack.convolve.init_convolution_kernel
==============================================

.. currentmodule:: scipy.fftpack.convolve

.. autodata:: init_convolution_kernel