scipy.maxentropy.bigmodel.setsampleFgen
=======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.setsampleFgen