scipy.misc.lena
===============

.. currentmodule:: scipy.misc

.. autofunction:: lena