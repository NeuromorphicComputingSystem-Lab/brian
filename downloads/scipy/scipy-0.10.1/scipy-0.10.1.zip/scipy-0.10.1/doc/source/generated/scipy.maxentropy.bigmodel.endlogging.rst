scipy.maxentropy.bigmodel.endlogging
====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.endlogging