scipy.maxentropy.model.normconst
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.normconst