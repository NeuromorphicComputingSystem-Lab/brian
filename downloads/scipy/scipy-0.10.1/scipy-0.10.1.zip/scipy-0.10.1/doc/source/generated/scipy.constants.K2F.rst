scipy.constants.K2F
===================

.. currentmodule:: scipy.constants

.. autofunction:: K2F