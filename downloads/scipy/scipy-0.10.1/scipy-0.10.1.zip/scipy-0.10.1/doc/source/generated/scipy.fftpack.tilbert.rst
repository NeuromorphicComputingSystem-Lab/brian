scipy.fftpack.tilbert
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: tilbert