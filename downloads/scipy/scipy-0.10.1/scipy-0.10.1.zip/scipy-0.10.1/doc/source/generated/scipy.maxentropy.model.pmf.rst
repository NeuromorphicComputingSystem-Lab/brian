scipy.maxentropy.model.pmf
==========================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.pmf