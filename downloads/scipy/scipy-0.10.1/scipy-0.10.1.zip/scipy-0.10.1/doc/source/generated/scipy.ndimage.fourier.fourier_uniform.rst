scipy.ndimage.fourier.fourier_uniform
=====================================

.. currentmodule:: scipy.ndimage.fourier

.. autofunction:: fourier_uniform