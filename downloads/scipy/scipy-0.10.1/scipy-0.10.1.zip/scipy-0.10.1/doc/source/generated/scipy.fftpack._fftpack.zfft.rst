scipy.fftpack._fftpack.zfft
===========================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: zfft