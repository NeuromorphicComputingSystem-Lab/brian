scipy.io.arff.loadarff
======================

.. currentmodule:: scipy.io.arff

.. autofunction:: loadarff