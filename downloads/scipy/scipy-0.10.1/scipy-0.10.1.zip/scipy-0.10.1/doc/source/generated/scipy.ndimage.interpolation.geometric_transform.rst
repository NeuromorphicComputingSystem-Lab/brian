scipy.ndimage.interpolation.geometric_transform
===============================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: geometric_transform