scipy.integrate.complex_ode.set_f_params
========================================

.. currentmodule:: scipy.integrate

.. automethod:: complex_ode.set_f_params