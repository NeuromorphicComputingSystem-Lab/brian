scipy.maxentropy.bigmodel.lognormconst
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.lognormconst