scipy.linalg.cholesky
=====================

.. currentmodule:: scipy.linalg

.. autofunction:: cholesky