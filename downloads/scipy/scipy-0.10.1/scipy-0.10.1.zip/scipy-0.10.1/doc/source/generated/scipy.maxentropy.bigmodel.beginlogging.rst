scipy.maxentropy.bigmodel.beginlogging
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.beginlogging