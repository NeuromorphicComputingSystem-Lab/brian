scipy.integrate.complex_ode.set_jac_params
==========================================

.. currentmodule:: scipy.integrate

.. automethod:: complex_ode.set_jac_params