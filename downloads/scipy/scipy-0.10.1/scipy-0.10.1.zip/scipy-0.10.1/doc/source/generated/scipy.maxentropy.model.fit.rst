scipy.maxentropy.model.fit
==========================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.fit