scipy.misc.factorial
====================

.. currentmodule:: scipy.misc

.. autofunction:: factorial