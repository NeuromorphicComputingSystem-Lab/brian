scipy.maxentropy.model.setsmooth
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.setsmooth