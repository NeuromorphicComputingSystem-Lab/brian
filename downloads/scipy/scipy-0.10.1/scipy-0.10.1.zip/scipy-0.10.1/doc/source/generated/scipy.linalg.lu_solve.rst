scipy.linalg.lu_solve
=====================

.. currentmodule:: scipy.linalg

.. autofunction:: lu_solve