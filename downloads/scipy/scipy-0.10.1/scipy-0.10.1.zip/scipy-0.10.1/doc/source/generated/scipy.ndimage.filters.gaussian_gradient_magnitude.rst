scipy.ndimage.filters.gaussian_gradient_magnitude
=================================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: gaussian_gradient_magnitude