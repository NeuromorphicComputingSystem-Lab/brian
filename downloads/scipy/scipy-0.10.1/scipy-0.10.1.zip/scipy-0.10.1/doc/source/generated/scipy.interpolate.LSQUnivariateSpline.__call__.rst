scipy.interpolate.LSQUnivariateSpline.__call__
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.__call__