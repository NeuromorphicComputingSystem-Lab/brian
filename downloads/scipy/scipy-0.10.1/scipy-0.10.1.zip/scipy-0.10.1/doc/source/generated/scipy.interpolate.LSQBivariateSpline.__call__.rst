scipy.interpolate.LSQBivariateSpline.__call__
=============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.__call__