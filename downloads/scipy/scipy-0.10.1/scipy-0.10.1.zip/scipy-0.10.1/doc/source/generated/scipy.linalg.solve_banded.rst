scipy.linalg.solve_banded
=========================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_banded