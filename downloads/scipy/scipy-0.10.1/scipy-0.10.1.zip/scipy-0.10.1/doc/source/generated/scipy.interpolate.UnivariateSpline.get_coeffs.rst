scipy.interpolate.UnivariateSpline.get_coeffs
=============================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.get_coeffs