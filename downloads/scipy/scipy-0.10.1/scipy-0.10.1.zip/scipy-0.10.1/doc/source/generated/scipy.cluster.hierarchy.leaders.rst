scipy.cluster.hierarchy.leaders
===============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: leaders