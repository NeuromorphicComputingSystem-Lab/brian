scipy.misc.imfilter
===================

.. currentmodule:: scipy.misc

.. autofunction:: imfilter