scipy.fftpack.shift
===================

.. currentmodule:: scipy.fftpack

.. autofunction:: shift