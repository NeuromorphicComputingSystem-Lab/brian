scipy.cluster.hierarchy.cophenet
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: cophenet