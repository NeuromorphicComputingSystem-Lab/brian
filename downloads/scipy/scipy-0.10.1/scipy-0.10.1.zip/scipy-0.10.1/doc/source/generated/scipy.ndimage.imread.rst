scipy.ndimage.imread
====================

.. currentmodule:: scipy.ndimage

.. autofunction:: imread