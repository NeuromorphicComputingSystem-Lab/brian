scipy.interpolate.Rbf.__call__
==============================

.. currentmodule:: scipy.interpolate

.. automethod:: Rbf.__call__