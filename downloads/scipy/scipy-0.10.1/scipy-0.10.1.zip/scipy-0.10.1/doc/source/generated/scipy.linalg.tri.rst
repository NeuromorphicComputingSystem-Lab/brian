scipy.linalg.tri
================

.. currentmodule:: scipy.linalg

.. autofunction:: tri