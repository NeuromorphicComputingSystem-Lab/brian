scipy.cluster.hierarchy.ClusterNode.get_id
==========================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.get_id