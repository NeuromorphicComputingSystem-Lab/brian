scipy.linalg.eigvals_banded
===========================

.. currentmodule:: scipy.linalg

.. autofunction:: eigvals_banded