scipy.interpolate.InterpolatedUnivariateSpline.roots
====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.roots