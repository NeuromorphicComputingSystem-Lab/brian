scipy.maxentropy.model.expectations
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.expectations