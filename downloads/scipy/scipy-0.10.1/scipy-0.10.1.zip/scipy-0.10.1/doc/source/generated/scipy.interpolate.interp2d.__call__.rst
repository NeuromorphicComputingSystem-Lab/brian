scipy.interpolate.interp2d.__call__
===================================

.. currentmodule:: scipy.interpolate

.. automethod:: interp2d.__call__