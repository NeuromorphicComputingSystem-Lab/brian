scipy.interpolate.KroghInterpolator.__call__
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: KroghInterpolator.__call__