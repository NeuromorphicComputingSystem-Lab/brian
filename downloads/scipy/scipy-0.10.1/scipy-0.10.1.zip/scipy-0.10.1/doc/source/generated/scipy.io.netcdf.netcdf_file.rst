scipy.io.netcdf.netcdf_file
===========================

.. currentmodule:: scipy.io.netcdf

.. autoclass:: netcdf_file

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         netcdf_file.close
         netcdf_file.createDimension
         netcdf_file.createVariable
         netcdf_file.flush
         netcdf_file.sync



   

