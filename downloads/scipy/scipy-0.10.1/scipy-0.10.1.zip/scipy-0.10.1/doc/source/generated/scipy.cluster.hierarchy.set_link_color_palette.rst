scipy.cluster.hierarchy.set_link_color_palette
==============================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: set_link_color_palette