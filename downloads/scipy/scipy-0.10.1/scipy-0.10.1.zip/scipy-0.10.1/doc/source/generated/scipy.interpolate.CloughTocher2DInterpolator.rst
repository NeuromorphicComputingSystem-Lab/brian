scipy.interpolate.CloughTocher2DInterpolator
============================================

.. currentmodule:: scipy.interpolate

.. autoclass:: CloughTocher2DInterpolator

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         CloughTocher2DInterpolator.__call__



   

