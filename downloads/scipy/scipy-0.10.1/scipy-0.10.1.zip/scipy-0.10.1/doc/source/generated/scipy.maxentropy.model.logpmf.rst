scipy.maxentropy.model.logpmf
=============================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.logpmf