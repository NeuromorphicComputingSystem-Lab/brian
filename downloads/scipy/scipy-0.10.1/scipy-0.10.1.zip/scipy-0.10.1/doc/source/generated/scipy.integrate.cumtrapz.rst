scipy.integrate.cumtrapz
========================

.. currentmodule:: scipy.integrate

.. autofunction:: cumtrapz