scipy.interpolate.RectBivariateSpline.__call__
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.__call__