scipy.integrate.complex_ode
===========================

.. currentmodule:: scipy.integrate

.. autoclass:: complex_ode

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         complex_ode.integrate
         complex_ode.set_f_params
         complex_ode.set_initial_value
         complex_ode.set_integrator
         complex_ode.set_jac_params
         complex_ode.successful



   

