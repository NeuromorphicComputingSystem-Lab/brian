scipy.maxentropy.basemodel.endlogging
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.endlogging