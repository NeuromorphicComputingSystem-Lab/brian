scipy.maxentropy.model.setparams
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.setparams