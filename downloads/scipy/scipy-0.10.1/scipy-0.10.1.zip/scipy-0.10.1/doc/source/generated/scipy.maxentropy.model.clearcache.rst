scipy.maxentropy.model.clearcache
=================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.clearcache