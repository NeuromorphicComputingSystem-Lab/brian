scipy.integrate.complex_ode.successful
======================================

.. currentmodule:: scipy.integrate

.. automethod:: complex_ode.successful