scipy.cluster.vq.kmeans2
========================

.. currentmodule:: scipy.cluster.vq

.. autofunction:: kmeans2