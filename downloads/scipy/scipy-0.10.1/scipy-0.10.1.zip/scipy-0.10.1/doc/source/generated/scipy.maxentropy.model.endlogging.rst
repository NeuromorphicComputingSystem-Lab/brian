scipy.maxentropy.model.endlogging
=================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.endlogging