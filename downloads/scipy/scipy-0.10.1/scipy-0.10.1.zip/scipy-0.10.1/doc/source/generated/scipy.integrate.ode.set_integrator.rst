scipy.integrate.ode.set_integrator
==================================

.. currentmodule:: scipy.integrate

.. automethod:: ode.set_integrator