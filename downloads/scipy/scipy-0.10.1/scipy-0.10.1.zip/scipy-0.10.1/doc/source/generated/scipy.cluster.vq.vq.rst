scipy.cluster.vq.vq
===================

.. currentmodule:: scipy.cluster.vq

.. autofunction:: vq