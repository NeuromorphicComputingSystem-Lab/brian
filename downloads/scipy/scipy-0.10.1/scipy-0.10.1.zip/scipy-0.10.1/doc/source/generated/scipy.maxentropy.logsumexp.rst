scipy.maxentropy.logsumexp
==========================

.. currentmodule:: scipy.maxentropy

.. autofunction:: logsumexp