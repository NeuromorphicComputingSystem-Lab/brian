scipy.maxentropy.basemodel.setcallback
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.setcallback