scipy.maxentropy.model.lognormconst
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.lognormconst