scipy.maxentropy.flatten
========================

.. currentmodule:: scipy.maxentropy

.. autofunction:: flatten