scipy.ndimage.interpolation.spline_filter1d
===========================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: spline_filter1d