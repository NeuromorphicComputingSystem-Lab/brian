scipy.cluster.vq.kmeans
=======================

.. currentmodule:: scipy.cluster.vq

.. autofunction:: kmeans