scipy.maxentropy.conditionalmodel.lognormconst
==============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.lognormconst