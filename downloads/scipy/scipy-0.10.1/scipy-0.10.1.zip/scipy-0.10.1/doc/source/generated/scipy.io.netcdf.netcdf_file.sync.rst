scipy.io.netcdf.netcdf_file.sync
================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_file.sync