scipy.interpolate.RectBivariateSpline.get_coeffs
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.get_coeffs