scipy.constants.C2K
===================

.. currentmodule:: scipy.constants

.. autofunction:: C2K