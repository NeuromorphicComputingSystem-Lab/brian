scipy.fftpack.fftshift
======================

.. currentmodule:: scipy.fftpack

.. autofunction:: fftshift