scipy.ndimage.filters.gaussian_filter1d
=======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: gaussian_filter1d