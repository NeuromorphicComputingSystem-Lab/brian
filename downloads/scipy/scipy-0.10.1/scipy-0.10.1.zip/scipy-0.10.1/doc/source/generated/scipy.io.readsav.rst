scipy.io.readsav
================

.. currentmodule:: scipy.io

.. autofunction:: readsav