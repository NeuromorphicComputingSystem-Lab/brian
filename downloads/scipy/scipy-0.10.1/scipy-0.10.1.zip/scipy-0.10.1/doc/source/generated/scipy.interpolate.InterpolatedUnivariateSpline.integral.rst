scipy.interpolate.InterpolatedUnivariateSpline.integral
=======================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.integral