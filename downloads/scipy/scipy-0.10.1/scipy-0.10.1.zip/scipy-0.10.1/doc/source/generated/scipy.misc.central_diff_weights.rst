scipy.misc.central_diff_weights
===============================

.. currentmodule:: scipy.misc

.. autofunction:: central_diff_weights