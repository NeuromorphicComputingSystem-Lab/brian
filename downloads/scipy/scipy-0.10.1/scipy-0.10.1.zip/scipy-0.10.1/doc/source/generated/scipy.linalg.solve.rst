scipy.linalg.solve
==================

.. currentmodule:: scipy.linalg

.. autofunction:: solve