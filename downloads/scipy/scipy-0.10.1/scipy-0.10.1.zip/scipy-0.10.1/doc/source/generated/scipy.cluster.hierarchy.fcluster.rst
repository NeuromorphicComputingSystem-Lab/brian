scipy.cluster.hierarchy.fcluster
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: fcluster