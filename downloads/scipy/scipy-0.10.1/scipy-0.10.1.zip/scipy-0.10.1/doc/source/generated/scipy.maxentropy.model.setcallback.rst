scipy.maxentropy.model.setcallback
==================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.setcallback