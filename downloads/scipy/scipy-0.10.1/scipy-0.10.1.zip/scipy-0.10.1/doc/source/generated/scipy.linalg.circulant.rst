scipy.linalg.circulant
======================

.. currentmodule:: scipy.linalg

.. autofunction:: circulant