.. automodule:: scipy.linalg
