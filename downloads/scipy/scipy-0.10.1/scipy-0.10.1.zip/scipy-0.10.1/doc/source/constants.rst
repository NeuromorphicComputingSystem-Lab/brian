.. automodule:: scipy.constants
