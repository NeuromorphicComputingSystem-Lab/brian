.. automodule:: scipy.stats

.. toctree::
   :hidden:
   
   scipy.stats.mstats
