/*<html><pre>  -<a                             href="qh-qhull.htm"
  >-------------------------------</a><a name="TOP">-</a>

   qhull.h

   Proxy for libqhull.h for backwards compatability

   copyright (c) 1993-2010 The Geometry Center.
   $Id: //product/qhull/main/rel/src/qhull.h#51 $$Change: 1188 $
   $DateTime: 2010/01/14 22:35:43 $$Author: bbarber $
*/

#ifndef qhDEFqhull
#define qhDEFqhull 1

#include "libqhull.h"

#endif /* qhDEFqhull */
