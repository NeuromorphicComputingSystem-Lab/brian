
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.10.1'
version = '0.10.1'
full_version = '0.10.1'
git_revision = '772893ff951c61f15a710b3b773ac12e69254fa4'
release = True

if not release:
    version = full_version
