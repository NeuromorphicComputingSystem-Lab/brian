__doc__ = """
n-dimensional image package
===========================

This package contains various functions for multi-dimensional image processing.
"""

postpone_import = 1
depends = []
