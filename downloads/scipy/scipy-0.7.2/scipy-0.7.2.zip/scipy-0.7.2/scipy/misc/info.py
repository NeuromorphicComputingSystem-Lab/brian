
"""
Various utilities that don't have another home.
"""

global_symbols = ['info','factorial','factorial2','factorialk','comb','who',
                  'lena','central_diff_weights', 'derivative', 'pade', 'source']
