
from info import __doc__, __all__

from numpy.testing import Tester
test = Tester().test
