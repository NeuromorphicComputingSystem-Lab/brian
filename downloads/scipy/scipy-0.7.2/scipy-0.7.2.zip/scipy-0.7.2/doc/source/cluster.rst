=========================================
Clustering package (:mod:`scipy.cluster`)
=========================================

.. toctree::

   cluster.hierarchy
   cluster.vq

.. automodule:: scipy.cluster
