scipy.ndimage.measurements.extrema
==================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: extrema