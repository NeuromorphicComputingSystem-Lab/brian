scipy.fftpack.ifft2
===================

.. currentmodule:: scipy.fftpack

.. autofunction:: ifft2