scipy.interpolate.LSQBivariateSpline.__init__
=============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.__init__