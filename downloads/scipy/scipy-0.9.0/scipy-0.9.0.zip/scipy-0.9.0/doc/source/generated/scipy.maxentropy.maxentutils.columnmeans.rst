scipy.maxentropy.maxentutils.columnmeans
========================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: columnmeans