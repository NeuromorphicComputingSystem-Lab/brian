scipy.misc.setup
================

.. automodule:: scipy.misc.setup

   
   
   .. rubric:: Functions

   .. autosummary::
   
      configuration
   
   

   
   
   

   
   
   