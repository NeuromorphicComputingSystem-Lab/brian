scipy.maxentropy.maxentutils.sparsefeaturematrix
================================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: sparsefeaturematrix