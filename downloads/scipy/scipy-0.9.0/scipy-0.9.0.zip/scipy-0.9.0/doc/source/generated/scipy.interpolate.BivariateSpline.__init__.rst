scipy.interpolate.BivariateSpline.__init__
==========================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.__init__