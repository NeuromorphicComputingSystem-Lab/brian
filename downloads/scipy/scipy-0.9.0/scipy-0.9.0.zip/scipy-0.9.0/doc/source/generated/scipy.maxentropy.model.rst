scipy.maxentropy.model
======================

.. currentmodule:: scipy.maxentropy

.. autoclass:: model

   

   .. HACK
      .. autosummary::
         :toctree:
      
         model.__init__
         model.beginlogging
         model.clearcache
         model.crossentropy
         model.dual
         model.endlogging
         model.entropydual
         model.expectations
         model.fit
         model.grad
         model.log
         model.lognormconst
         model.logparams
         model.logpmf
         model.normconst
         model.pmf
         model.pmf_function
         model.probdist
         model.reset
         model.setcallback
         model.setfeaturesandsamplespace
         model.setparams
         model.setsmooth



   

