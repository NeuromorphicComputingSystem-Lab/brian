scipy.interpolate.CloughTocher2DInterpolator
============================================

.. currentmodule:: scipy.interpolate

.. autoclass:: CloughTocher2DInterpolator

   

   .. HACK
      .. autosummary::
         :toctree:
      
         CloughTocher2DInterpolator.__init__



   

