scipy.maxentropy.maxentutils.dotprod
====================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: dotprod