scipy.interpolate.NearestNDInterpolator.__init__
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: NearestNDInterpolator.__init__