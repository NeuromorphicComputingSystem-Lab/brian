scipy.cluster.hierarchy.ClusterNode.pre_order
=============================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.pre_order