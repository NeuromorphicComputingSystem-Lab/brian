scipy.interpolate.barycentric_interpolate
=========================================

.. currentmodule:: scipy.interpolate

.. autofunction:: barycentric_interpolate