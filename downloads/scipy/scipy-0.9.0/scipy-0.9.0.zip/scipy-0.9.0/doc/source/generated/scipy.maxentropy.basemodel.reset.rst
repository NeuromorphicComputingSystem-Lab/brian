scipy.maxentropy.basemodel.reset
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.reset