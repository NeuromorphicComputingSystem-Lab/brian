scipy.cluster.hierarchy.maxinconsts
===================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: maxinconsts