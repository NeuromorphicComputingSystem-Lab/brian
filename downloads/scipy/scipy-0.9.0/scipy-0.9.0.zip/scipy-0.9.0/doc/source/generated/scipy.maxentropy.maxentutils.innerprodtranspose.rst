scipy.maxentropy.maxentutils.innerprodtranspose
===============================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: innerprodtranspose