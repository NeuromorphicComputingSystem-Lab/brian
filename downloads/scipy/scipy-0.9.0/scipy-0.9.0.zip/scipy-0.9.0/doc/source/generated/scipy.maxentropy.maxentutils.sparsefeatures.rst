scipy.maxentropy.maxentutils.sparsefeatures
===========================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: sparsefeatures