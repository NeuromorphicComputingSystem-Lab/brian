scipy.linalg.expm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: expm