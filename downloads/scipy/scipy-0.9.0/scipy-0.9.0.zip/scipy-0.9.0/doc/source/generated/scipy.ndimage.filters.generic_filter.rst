scipy.ndimage.filters.generic_filter
====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: generic_filter