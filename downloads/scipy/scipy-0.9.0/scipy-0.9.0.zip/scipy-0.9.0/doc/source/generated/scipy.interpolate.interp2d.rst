scipy.interpolate.interp2d
==========================

.. currentmodule:: scipy.interpolate

.. autoclass:: interp2d

   

   .. HACK
      .. autosummary::
         :toctree:
      
         interp2d.__init__



   

