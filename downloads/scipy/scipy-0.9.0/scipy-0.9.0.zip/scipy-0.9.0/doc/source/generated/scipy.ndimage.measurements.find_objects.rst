scipy.ndimage.measurements.find_objects
=======================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: find_objects