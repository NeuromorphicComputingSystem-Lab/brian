scipy.interpolate.NearestNDInterpolator
=======================================

.. currentmodule:: scipy.interpolate

.. autoclass:: NearestNDInterpolator

   

   .. HACK
      .. autosummary::
         :toctree:
      
         NearestNDInterpolator.__init__



   

