scipy.maxentropy.sparsefeaturematrix
====================================

.. currentmodule:: scipy.maxentropy

.. autofunction:: sparsefeaturematrix