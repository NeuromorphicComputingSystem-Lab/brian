scipy.maxentropy.basemodel.setparams
====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.setparams