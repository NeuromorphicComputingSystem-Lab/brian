scipy.maxentropy.basemodel.crossentropy
=======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.crossentropy