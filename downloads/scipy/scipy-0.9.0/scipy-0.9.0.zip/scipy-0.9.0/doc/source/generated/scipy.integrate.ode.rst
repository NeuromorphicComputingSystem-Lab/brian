scipy.integrate.ode
===================

.. currentmodule:: scipy.integrate

.. autoclass:: ode

   

   .. HACK
      .. autosummary::
         :toctree:
      
         ode.__init__
         ode.integrate
         ode.set_f_params
         ode.set_initial_value
         ode.set_integrator
         ode.set_jac_params
         ode.successful



   

