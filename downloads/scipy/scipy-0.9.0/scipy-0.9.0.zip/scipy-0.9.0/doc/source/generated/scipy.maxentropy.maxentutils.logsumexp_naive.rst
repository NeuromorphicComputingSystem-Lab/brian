scipy.maxentropy.maxentutils.logsumexp_naive
============================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: logsumexp_naive