scipy.interpolate.PiecewisePolynomial.extend
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.extend