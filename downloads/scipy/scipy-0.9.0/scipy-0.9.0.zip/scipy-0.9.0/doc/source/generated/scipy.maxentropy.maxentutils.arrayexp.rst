scipy.maxentropy.maxentutils.arrayexp
=====================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: arrayexp