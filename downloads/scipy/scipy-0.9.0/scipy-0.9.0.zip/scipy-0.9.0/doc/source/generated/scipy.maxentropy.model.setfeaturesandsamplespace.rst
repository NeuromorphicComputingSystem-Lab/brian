scipy.maxentropy.model.setfeaturesandsamplespace
================================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.setfeaturesandsamplespace