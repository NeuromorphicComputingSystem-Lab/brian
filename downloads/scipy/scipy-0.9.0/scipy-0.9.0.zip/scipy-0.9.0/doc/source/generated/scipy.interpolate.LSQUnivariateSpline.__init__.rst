scipy.interpolate.LSQUnivariateSpline.__init__
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.__init__