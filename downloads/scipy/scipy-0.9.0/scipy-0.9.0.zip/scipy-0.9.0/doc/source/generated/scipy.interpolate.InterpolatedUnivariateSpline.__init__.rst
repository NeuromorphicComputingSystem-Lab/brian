scipy.interpolate.InterpolatedUnivariateSpline.__init__
=======================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.__init__