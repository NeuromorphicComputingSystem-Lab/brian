scipy.maxentropy.maxentutils.arrayexpcomplex
============================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: arrayexpcomplex