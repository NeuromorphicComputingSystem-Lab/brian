scipy.linalg.sinhm
==================

.. currentmodule:: scipy.linalg

.. autofunction:: sinhm