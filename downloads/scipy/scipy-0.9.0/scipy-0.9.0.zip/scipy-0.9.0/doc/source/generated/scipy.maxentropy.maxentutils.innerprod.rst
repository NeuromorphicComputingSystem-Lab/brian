scipy.maxentropy.maxentutils.innerprod
======================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: innerprod