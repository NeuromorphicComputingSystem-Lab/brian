scipy.maxentropy.bigmodel.setparams
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.setparams