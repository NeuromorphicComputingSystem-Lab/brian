scipy.interpolate.BarycentricInterpolator.add_xi
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: BarycentricInterpolator.add_xi