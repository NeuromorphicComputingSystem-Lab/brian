scipy.misc.imsave
=================

.. currentmodule:: scipy.misc

.. autofunction:: imsave