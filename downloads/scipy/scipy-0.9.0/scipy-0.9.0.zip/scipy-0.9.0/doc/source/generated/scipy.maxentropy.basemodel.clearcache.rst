scipy.maxentropy.basemodel.clearcache
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.clearcache