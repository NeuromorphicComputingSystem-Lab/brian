scipy.interpolate.Rbf.__init__
==============================

.. currentmodule:: scipy.interpolate

.. automethod:: Rbf.__init__