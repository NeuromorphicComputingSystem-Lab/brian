scipy.maxentropy.maxentutils.densefeaturematrix
===============================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: densefeaturematrix