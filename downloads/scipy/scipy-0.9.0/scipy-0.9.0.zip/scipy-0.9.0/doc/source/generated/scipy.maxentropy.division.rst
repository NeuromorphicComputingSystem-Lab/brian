scipy.maxentropy.division
=========================

.. currentmodule:: scipy.maxentropy

.. autodata:: division