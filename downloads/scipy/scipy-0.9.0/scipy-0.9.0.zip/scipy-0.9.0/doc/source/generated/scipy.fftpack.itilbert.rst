scipy.fftpack.itilbert
======================

.. currentmodule:: scipy.fftpack

.. autofunction:: itilbert