scipy.maxentropy.conditionalmodel.setsmooth
===========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.setsmooth