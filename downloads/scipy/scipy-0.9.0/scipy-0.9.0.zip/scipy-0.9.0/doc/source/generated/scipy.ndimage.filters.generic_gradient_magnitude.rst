scipy.ndimage.filters.generic_gradient_magnitude
================================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: generic_gradient_magnitude