scipy.cluster.hierarchy.ClusterNode.__init__
============================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.__init__