scipy.interpolate.PiecewisePolynomial
=====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: PiecewisePolynomial

   

   .. HACK
      .. autosummary::
         :toctree:
      
         PiecewisePolynomial.__init__
         PiecewisePolynomial.append
         PiecewisePolynomial.derivative
         PiecewisePolynomial.derivatives
         PiecewisePolynomial.extend



   

