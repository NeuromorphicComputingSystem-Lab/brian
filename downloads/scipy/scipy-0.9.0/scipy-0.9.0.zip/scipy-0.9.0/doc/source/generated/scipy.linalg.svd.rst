scipy.linalg.svd
================

.. currentmodule:: scipy.linalg

.. autofunction:: svd