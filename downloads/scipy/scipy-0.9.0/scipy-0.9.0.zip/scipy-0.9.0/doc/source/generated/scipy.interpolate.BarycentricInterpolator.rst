scipy.interpolate.BarycentricInterpolator
=========================================

.. currentmodule:: scipy.interpolate

.. autoclass:: BarycentricInterpolator

   

   .. HACK
      .. autosummary::
         :toctree:
      
         BarycentricInterpolator.__init__
         BarycentricInterpolator.add_xi
         BarycentricInterpolator.set_yi



   

