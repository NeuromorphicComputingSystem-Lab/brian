scipy.interpolate.BivariateSpline.get_residual
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.get_residual