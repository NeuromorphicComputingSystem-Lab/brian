scipy.interpolate.CloughTocher2DInterpolator.__init__
=====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: CloughTocher2DInterpolator.__init__