scipy.interpolate.KroghInterpolator.__init__
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: KroghInterpolator.__init__