scipy.fftpack._fftpack.destroy_drfft_cache
==========================================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: destroy_drfft_cache