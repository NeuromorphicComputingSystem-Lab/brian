scipy.maxentropy.maxentutils.columnvariances
============================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: columnvariances