scipy.interpolate.SmoothBivariateSpline
=======================================

.. currentmodule:: scipy.interpolate

.. autoclass:: SmoothBivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         SmoothBivariateSpline.__init__
         SmoothBivariateSpline.ev
         SmoothBivariateSpline.get_coeffs
         SmoothBivariateSpline.get_knots
         SmoothBivariateSpline.get_residual
         SmoothBivariateSpline.integral



   

