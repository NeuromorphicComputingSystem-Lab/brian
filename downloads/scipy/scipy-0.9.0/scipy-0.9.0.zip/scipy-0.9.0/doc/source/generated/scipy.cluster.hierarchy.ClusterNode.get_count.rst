scipy.cluster.hierarchy.ClusterNode.get_count
=============================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.get_count