scipy.cluster.hierarchy.weighted
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: weighted