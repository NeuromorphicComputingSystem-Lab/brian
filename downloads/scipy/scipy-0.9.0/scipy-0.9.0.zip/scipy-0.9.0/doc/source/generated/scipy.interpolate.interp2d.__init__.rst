scipy.interpolate.interp2d.__init__
===================================

.. currentmodule:: scipy.interpolate

.. automethod:: interp2d.__init__