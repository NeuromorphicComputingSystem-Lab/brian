scipy.maxentropy.innerprodtranspose
===================================

.. currentmodule:: scipy.maxentropy

.. autofunction:: innerprodtranspose