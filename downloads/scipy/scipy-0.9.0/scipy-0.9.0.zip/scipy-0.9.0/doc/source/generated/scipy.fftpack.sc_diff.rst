scipy.fftpack.sc_diff
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: sc_diff