scipy.linalg.expm3
==================

.. currentmodule:: scipy.linalg

.. autofunction:: expm3