scipy.cluster.hierarchy.ClusterNode.is_leaf
===========================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.is_leaf