scipy.maxentropy.maxentutils.rowmeans
=====================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: rowmeans