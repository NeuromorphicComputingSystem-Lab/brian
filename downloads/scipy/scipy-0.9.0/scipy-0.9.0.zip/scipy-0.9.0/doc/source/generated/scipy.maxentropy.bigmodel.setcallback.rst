scipy.maxentropy.bigmodel.setcallback
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.setcallback