scipy.ndimage.filters.prewitt
=============================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: prewitt