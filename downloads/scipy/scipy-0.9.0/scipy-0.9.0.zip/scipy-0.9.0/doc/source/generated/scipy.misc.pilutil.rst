scipy.misc.pilutil
==================

.. automodule:: scipy.misc.pilutil

   
   
   .. rubric:: Functions

   .. autosummary::
   
      amax
      amin
      arange
      array
      asarray
      bytescale
      fromimage
      imfilter
      imread
      imresize
      imrotate
      imsave
      imshow
      iscomplexobj
      issubdtype
      ones
      radon
      ravel
      sum
      toimage
      transpose
      zeros
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      uint8
   
   

   
   
   