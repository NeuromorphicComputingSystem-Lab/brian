scipy.fftpack.fft2
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: fft2