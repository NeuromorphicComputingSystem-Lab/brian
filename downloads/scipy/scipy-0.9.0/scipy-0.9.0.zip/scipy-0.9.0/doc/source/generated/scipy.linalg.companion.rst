scipy.linalg.companion
======================

.. currentmodule:: scipy.linalg

.. autofunction:: companion