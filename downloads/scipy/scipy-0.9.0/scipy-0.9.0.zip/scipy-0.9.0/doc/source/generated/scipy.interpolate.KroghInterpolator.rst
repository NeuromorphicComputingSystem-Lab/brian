scipy.interpolate.KroghInterpolator
===================================

.. currentmodule:: scipy.interpolate

.. autoclass:: KroghInterpolator

   

   .. HACK
      .. autosummary::
         :toctree:
      
         KroghInterpolator.__init__
         KroghInterpolator.derivative
         KroghInterpolator.derivatives



   

