scipy.misc.setupscons
=====================

.. automodule:: scipy.misc.setupscons

   
   
   .. rubric:: Functions

   .. autosummary::
   
      configuration
   
   

   
   
   

   
   
   