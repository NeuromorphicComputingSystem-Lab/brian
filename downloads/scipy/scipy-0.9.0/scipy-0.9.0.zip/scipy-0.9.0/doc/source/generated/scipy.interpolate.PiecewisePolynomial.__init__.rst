scipy.interpolate.PiecewisePolynomial.__init__
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.__init__