scipy.interpolate.splprep
=========================

.. currentmodule:: scipy.interpolate

.. autofunction:: splprep