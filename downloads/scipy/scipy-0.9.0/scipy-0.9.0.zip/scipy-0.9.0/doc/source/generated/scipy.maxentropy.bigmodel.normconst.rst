scipy.maxentropy.bigmodel.normconst
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.normconst