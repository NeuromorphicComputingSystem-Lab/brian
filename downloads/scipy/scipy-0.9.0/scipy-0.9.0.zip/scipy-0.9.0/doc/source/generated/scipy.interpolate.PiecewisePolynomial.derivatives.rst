scipy.interpolate.PiecewisePolynomial.derivatives
=================================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.derivatives