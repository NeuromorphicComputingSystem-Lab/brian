scipy.maxentropy.bigmodel.resample
==================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.resample