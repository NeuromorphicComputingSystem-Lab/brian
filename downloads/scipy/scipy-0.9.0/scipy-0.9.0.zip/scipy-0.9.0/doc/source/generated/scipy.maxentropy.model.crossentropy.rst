scipy.maxentropy.model.crossentropy
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.crossentropy