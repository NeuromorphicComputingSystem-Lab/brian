scipy.cluster.hierarchy.is_valid_linkage
========================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: is_valid_linkage