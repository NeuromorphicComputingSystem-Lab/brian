scipy.maxentropy.basemodel.grad
===============================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.grad