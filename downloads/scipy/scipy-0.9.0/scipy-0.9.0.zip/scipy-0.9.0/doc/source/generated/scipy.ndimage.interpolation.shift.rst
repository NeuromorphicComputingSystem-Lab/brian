scipy.ndimage.interpolation.shift
=================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: shift