scipy.interpolate.UnivariateSpline.__call__
===========================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.__call__