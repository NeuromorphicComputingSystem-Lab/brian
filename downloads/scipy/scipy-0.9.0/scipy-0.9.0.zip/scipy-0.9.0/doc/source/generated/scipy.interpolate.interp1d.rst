scipy.interpolate.interp1d
==========================

.. currentmodule:: scipy.interpolate

.. autoclass:: interp1d

   

   .. HACK
      .. autosummary::
         :toctree:
      
         interp1d.__init__



   

