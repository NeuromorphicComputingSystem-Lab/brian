scipy.io.savemat
================

.. currentmodule:: scipy.io

.. autofunction:: savemat