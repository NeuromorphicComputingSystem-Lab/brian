scipy.interpolate.LSQUnivariateSpline.integral
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.integral