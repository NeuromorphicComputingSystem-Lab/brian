scipy.interpolate.LSQBivariateSpline
====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: LSQBivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         LSQBivariateSpline.__init__
         LSQBivariateSpline.ev
         LSQBivariateSpline.get_coeffs
         LSQBivariateSpline.get_knots
         LSQBivariateSpline.get_residual
         LSQBivariateSpline.integral



   

