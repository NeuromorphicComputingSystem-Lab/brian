scipy.maxentropy.maxentutils.robustlog
======================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: robustlog