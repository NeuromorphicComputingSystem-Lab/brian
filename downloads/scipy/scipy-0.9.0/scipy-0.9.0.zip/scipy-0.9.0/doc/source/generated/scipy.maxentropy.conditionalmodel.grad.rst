scipy.maxentropy.conditionalmodel.grad
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.grad