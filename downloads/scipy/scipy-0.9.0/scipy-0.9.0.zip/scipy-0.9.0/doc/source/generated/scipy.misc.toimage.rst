scipy.misc.toimage
==================

.. currentmodule:: scipy.misc

.. autofunction:: toimage