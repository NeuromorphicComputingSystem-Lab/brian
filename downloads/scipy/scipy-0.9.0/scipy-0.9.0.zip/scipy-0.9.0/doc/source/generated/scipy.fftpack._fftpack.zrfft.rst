scipy.fftpack._fftpack.zrfft
============================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: zrfft