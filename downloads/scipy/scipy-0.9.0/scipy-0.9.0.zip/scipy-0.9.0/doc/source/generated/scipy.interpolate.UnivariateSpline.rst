scipy.interpolate.UnivariateSpline
==================================

.. currentmodule:: scipy.interpolate

.. autoclass:: UnivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         UnivariateSpline.__init__
         UnivariateSpline.derivatives
         UnivariateSpline.get_coeffs
         UnivariateSpline.get_knots
         UnivariateSpline.get_residual
         UnivariateSpline.integral
         UnivariateSpline.roots
         UnivariateSpline.set_smoothing_factor



   

