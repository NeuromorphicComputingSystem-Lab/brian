scipy.io.loadmat
================

.. currentmodule:: scipy.io

.. autofunction:: loadmat