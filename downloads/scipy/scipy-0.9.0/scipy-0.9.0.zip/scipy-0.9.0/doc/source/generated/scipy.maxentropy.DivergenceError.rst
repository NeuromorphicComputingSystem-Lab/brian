scipy.maxentropy.DivergenceError
================================

.. currentmodule:: scipy.maxentropy

.. autoexception:: DivergenceError