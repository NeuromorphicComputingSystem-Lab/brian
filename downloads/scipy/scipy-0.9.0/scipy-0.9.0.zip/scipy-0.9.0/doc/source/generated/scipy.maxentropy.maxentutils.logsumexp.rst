scipy.maxentropy.maxentutils.logsumexp
======================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: logsumexp