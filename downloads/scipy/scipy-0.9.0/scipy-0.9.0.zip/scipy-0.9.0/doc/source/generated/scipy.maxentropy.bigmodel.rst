scipy.maxentropy.bigmodel
=========================

.. currentmodule:: scipy.maxentropy

.. autoclass:: bigmodel

   

   .. HACK
      .. autosummary::
         :toctree:
      
         bigmodel.__init__
         bigmodel.beginlogging
         bigmodel.clearcache
         bigmodel.crossentropy
         bigmodel.dual
         bigmodel.endlogging
         bigmodel.entropydual
         bigmodel.estimate
         bigmodel.expectations
         bigmodel.fit
         bigmodel.grad
         bigmodel.log
         bigmodel.lognormconst
         bigmodel.logparams
         bigmodel.logpdf
         bigmodel.normconst
         bigmodel.pdf
         bigmodel.pdf_function
         bigmodel.resample
         bigmodel.reset
         bigmodel.setcallback
         bigmodel.setparams
         bigmodel.setsampleFgen
         bigmodel.setsmooth
         bigmodel.settestsamples
         bigmodel.stochapprox
         bigmodel.test



   

