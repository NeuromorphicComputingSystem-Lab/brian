scipy.maxentropy.basemodel.normconst
====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.normconst