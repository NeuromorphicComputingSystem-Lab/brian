scipy.interpolate.UnivariateSpline.roots
========================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.roots