scipy.maxentropy.bigmodel.__init__
==================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.__init__