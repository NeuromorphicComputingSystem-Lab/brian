scipy.interpolate.InterpolatedUnivariateSpline
==============================================

.. currentmodule:: scipy.interpolate

.. autoclass:: InterpolatedUnivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         InterpolatedUnivariateSpline.__init__
         InterpolatedUnivariateSpline.derivatives
         InterpolatedUnivariateSpline.get_coeffs
         InterpolatedUnivariateSpline.get_knots
         InterpolatedUnivariateSpline.get_residual
         InterpolatedUnivariateSpline.integral
         InterpolatedUnivariateSpline.roots
         InterpolatedUnivariateSpline.set_smoothing_factor



   

