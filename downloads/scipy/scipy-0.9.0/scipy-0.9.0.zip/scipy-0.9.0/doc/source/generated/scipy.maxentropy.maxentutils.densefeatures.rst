scipy.maxentropy.maxentutils.densefeatures
==========================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: densefeatures