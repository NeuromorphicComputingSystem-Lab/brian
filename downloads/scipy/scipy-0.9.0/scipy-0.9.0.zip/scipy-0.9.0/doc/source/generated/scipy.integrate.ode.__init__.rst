scipy.integrate.ode.__init__
============================

.. currentmodule:: scipy.integrate.ode

.. autodata:: __init__