scipy.maxentropy.arrayexp
=========================

.. currentmodule:: scipy.maxentropy

.. autofunction:: arrayexp