scipy.interpolate.LSQUnivariateSpline.get_knots
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.get_knots