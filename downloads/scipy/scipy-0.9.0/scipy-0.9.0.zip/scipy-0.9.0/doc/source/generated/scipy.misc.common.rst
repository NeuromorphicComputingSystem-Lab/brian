scipy.misc.common
=================

.. automodule:: scipy.misc.common

   
   
   .. rubric:: Functions

   .. autosummary::
   
      arange
      array
      asarray
      central_diff_weights
      comb
      derivative
      dot
      extract
      eye
      factorial
      factorial2
      factorialk
      hstack
      lena
      pade
      place
      product
      where
      zeros
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      poly1d
   
   

   
   
   