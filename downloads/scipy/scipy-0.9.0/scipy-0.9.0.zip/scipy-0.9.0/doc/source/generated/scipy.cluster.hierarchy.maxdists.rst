scipy.cluster.hierarchy.maxdists
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: maxdists