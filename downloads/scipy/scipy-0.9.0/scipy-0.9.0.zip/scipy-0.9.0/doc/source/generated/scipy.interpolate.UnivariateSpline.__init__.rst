scipy.interpolate.UnivariateSpline.__init__
===========================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.__init__