scipy.maxentropy.basemodel.__init__
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.__init__