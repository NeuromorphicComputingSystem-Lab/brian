scipy.maxentropy.innerprod
==========================

.. currentmodule:: scipy.maxentropy

.. autofunction:: innerprod