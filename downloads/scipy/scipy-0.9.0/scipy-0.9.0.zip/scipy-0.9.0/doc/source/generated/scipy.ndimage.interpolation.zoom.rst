scipy.ndimage.interpolation.zoom
================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: zoom