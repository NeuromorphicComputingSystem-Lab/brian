scipy.interpolate.LinearNDInterpolator.__init__
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LinearNDInterpolator.__init__