scipy.ndimage.filters.generic_filter1d
======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: generic_filter1d