scipy.maxentropy.basemodel
==========================

.. currentmodule:: scipy.maxentropy

.. autoclass:: basemodel

   

   .. HACK
      .. autosummary::
         :toctree:
      
         basemodel.__init__
         basemodel.beginlogging
         basemodel.clearcache
         basemodel.crossentropy
         basemodel.dual
         basemodel.endlogging
         basemodel.entropydual
         basemodel.fit
         basemodel.grad
         basemodel.log
         basemodel.logparams
         basemodel.normconst
         basemodel.reset
         basemodel.setcallback
         basemodel.setparams
         basemodel.setsmooth



   

