scipy.io.netcdf.netcdf_variable.__init__
========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_variable.__init__