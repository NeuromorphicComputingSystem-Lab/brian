scipy.interpolate.BivariateSpline
=================================

.. currentmodule:: scipy.interpolate

.. autoclass:: BivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         BivariateSpline.__init__
         BivariateSpline.ev
         BivariateSpline.get_coeffs
         BivariateSpline.get_knots
         BivariateSpline.get_residual
         BivariateSpline.integral



   

