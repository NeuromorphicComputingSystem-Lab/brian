scipy.interpolate.LSQUnivariateSpline
=====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: LSQUnivariateSpline

   

   .. HACK
      .. autosummary::
         :toctree:
      
         LSQUnivariateSpline.__init__
         LSQUnivariateSpline.derivatives
         LSQUnivariateSpline.get_coeffs
         LSQUnivariateSpline.get_knots
         LSQUnivariateSpline.get_residual
         LSQUnivariateSpline.integral
         LSQUnivariateSpline.roots
         LSQUnivariateSpline.set_smoothing_factor



   

