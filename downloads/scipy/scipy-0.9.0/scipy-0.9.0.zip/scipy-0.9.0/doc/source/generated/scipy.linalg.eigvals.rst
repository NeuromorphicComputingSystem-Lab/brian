scipy.linalg.eigvals
====================

.. currentmodule:: scipy.linalg

.. autofunction:: eigvals