scipy.cluster.hierarchy.ClusterNode.get_right
=============================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.get_right