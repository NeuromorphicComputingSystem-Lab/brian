scipy.io.netcdf.netcdf_file.__init__
====================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_file.__init__