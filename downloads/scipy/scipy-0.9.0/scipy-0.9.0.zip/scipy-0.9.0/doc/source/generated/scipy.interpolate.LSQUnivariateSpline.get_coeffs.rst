scipy.interpolate.LSQUnivariateSpline.get_coeffs
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.get_coeffs