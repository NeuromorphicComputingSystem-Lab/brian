scipy.fftpack.fftfreq
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: fftfreq