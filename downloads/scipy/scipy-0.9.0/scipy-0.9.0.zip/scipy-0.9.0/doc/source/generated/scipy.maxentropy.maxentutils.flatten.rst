scipy.maxentropy.maxentutils.flatten
====================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: flatten