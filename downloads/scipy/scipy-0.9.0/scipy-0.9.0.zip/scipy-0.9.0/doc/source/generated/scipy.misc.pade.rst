scipy.misc.pade
===============

.. currentmodule:: scipy.misc

.. autofunction:: pade