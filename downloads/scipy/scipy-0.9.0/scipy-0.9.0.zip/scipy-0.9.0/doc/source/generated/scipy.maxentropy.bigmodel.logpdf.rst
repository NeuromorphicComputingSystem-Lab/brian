scipy.maxentropy.bigmodel.logpdf
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.logpdf