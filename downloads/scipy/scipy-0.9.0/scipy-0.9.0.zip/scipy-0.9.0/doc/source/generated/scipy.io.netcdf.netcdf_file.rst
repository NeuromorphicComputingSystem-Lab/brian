scipy.io.netcdf.netcdf_file
===========================

.. currentmodule:: scipy.io.netcdf

.. autoclass:: netcdf_file

   

   .. HACK
      .. autosummary::
         :toctree:
      
         netcdf_file.__init__
         netcdf_file.close
         netcdf_file.createDimension
         netcdf_file.createVariable
         netcdf_file.flush
         netcdf_file.sync



   

