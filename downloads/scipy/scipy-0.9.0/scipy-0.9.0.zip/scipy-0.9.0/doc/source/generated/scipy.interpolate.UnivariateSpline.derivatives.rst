scipy.interpolate.UnivariateSpline.derivatives
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.derivatives