scipy.maxentropy.model.__init__
===============================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.__init__