scipy.maxentropy.conditionalmodel.__init__
==========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.__init__