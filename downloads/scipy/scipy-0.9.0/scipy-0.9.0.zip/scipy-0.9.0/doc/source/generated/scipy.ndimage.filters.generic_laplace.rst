scipy.ndimage.filters.generic_laplace
=====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: generic_laplace