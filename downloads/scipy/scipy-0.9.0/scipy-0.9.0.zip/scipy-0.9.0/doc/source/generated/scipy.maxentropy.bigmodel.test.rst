scipy.maxentropy.bigmodel.test
==============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.test