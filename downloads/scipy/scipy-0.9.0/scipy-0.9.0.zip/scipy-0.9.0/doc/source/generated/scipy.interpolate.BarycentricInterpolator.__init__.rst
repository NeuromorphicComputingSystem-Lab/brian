scipy.interpolate.BarycentricInterpolator.__init__
==================================================

.. currentmodule:: scipy.interpolate

.. automethod:: BarycentricInterpolator.__init__