scipy.constants.value
=====================

.. currentmodule:: scipy.constants

.. autofunction:: value