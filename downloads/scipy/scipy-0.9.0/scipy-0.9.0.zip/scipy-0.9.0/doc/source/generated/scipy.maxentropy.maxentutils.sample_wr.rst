scipy.maxentropy.maxentutils.sample_wr
======================================

.. currentmodule:: scipy.maxentropy.maxentutils

.. autofunction:: sample_wr