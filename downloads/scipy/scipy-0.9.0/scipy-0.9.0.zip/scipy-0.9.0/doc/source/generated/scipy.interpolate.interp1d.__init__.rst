scipy.interpolate.interp1d.__init__
===================================

.. currentmodule:: scipy.interpolate

.. automethod:: interp1d.__init__