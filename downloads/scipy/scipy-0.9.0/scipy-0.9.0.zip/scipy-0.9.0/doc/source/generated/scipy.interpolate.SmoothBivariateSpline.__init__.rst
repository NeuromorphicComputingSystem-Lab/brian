scipy.interpolate.SmoothBivariateSpline.__init__
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.__init__