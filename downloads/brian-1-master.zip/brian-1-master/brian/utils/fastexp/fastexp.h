void fastexp(double *x, int n, double *y, int m);
