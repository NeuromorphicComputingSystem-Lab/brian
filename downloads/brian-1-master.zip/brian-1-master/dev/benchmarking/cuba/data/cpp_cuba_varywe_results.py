# vary weights
# state updater matrix
cpp_cuba = []
cur_result = []
cur_result.append((0.718, 13579))
cur_result.append((0.719, 15140))
cur_result.append((0.719, 13051))
cur_result.append((0.734, 13342))
cur_result.append((0.734, 14620))
cur_result.append((0.735, 13061))
cur_result.append((0.735, 12719))
# we = 1.62
cpp_cuba.append((1000, 0.727714, 13644, cur_result))
cur_result = []
cur_result.append((0.734, 21315))
cur_result.append((0.734, 19045))
cur_result.append((0.734, 18084))
cur_result.append((0.734, 16624))
cur_result.append((0.735, 20383))
cur_result.append((0.735, 20307))
cur_result.append((0.735, 16269))
# we = 2.4
cpp_cuba.append((1000, 0.734429, 18861, cur_result))
cur_result = []
cur_result.append((0.735, 19993))
cur_result.append((0.735, 25975))
cur_result.append((0.75, 23947))
cur_result.append((0.75, 24037))
cur_result.append((0.75, 27073))
cur_result.append((0.75, 27273))
cur_result.append((0.75, 23499))
# we = 2.9
cpp_cuba.append((1000, 0.745714, 24542, cur_result))
cur_result = []
cur_result.append((0.734, 24987))
cur_result.append((0.734, 25586))
cur_result.append((0.734, 21295))
cur_result.append((0.735, 26025))
cur_result.append((0.75, 23231))
cur_result.append((0.75, 27206))
cur_result.append((0.75, 28540))
# we = 3.2
cpp_cuba.append((1000, 0.741, 25267, cur_result))
