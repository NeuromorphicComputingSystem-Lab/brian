# vary weights
# state updater matrix
cpp_cuba = []
cur_result = []
cur_result.append((3.015, 56409))
cur_result.append((3.031, 57891))
cur_result.append((3.032, 55646))
cur_result.append((3.046, 55931))
cur_result.append((3.047, 56880))
cur_result.append((3.047, 58541))
cur_result.append((3.047, 55876))
# we = 1.62
cpp_cuba.append((4000, 3.03786, 56739, cur_result))
cur_result = []
cur_result.append((3.015, 75145))
cur_result.append((3.047, 77944))
cur_result.append((3.078, 84491))
cur_result.append((3.078, 73464))
cur_result.append((3.078, 74534))
cur_result.append((3.093, 75515))
cur_result.append((3.094, 79403))
# we = 2.4
cpp_cuba.append((4000, 3.069, 77213, cur_result))
cur_result = []
cur_result.append((3.063, 100789))
cur_result.append((3.078, 87112))
cur_result.append((3.079, 103179))
cur_result.append((3.109, 98336))
cur_result.append((3.11, 109254))
cur_result.append((3.125, 98400))
cur_result.append((3.156, 103958))
# we = 2.9
cpp_cuba.append((4000, 3.10286, 100146, cur_result))
cur_result = []
cur_result.append((3.094, 98138))
cur_result.append((3.14, 115752))
cur_result.append((3.141, 108803))
cur_result.append((3.141, 114630))
cur_result.append((3.141, 118636))
cur_result.append((3.156, 101919))
cur_result.append((3.156, 113417))
# we = 3.2
cpp_cuba.append((4000, 3.13843, 110185, cur_result))
