# vary weights
# state updater matrix
cpp_cuba = []
cur_result = []
cur_result.append((0.719, 11483))
cur_result.append((0.719, 12639))
cur_result.append((0.719, 13725))
cur_result.append((0.734, 14989))
cur_result.append((0.734, 11584))
cur_result.append((0.735, 14212))
cur_result.append((0.735, 12722))
# we = 1.62
cpp_cuba.append((1000, 0.727857, 13050, cur_result))
cur_result = []
cur_result.append((0.718, 14607))
cur_result.append((0.734, 19707))
cur_result.append((0.734, 18944))
cur_result.append((0.734, 19395))
cur_result.append((0.735, 16693))
cur_result.append((0.735, 15263))
cur_result.append((0.735, 15468))
# we = 2.4
cpp_cuba.append((1000, 0.732143, 17153, cur_result))
cur_result = []
cur_result.append((0.734, 23597))
cur_result.append((0.734, 21946))
cur_result.append((0.734, 24026))
cur_result.append((0.735, 23047))
cur_result.append((0.735, 25863))
cur_result.append((0.75, 24000))
cur_result.append((0.75, 25434))
# we = 2.9
cpp_cuba.append((1000, 0.738857, 23987, cur_result))
cur_result = []
cur_result.append((0.734, 20868))
cur_result.append((0.75, 27938))
cur_result.append((0.75, 29506))
cur_result.append((0.75, 21027))
cur_result.append((0.75, 27691))
cur_result.append((0.75, 28883))
cur_result.append((0.75, 28942))
# we = 3.2
cpp_cuba.append((1000, 0.747714, 26407, cur_result))
