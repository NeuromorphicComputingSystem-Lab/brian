***********
Performance
***********

.. note:: XXX: This section is not yet written.

.. automodule:: numpy.doc.performance
