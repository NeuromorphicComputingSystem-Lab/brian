*************************
How to find documentation
*************************

.. seealso:: :ref:`Numpy-specific help functions <routines.help>`

.. note:: XXX: this part is not yet written.

.. automodule:: numpy.doc.howtofind
