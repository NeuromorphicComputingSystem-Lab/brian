************
Broadcasting
************

.. automodule:: numpy.doc.byteswapping
