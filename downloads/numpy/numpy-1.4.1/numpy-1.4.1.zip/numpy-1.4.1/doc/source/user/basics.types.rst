**********
Data types
**********

.. seealso:: :ref:`Data type objects <arrays.dtypes>`

.. note::

   XXX: Combine ``numpy.doc.indexing`` with material from
   "Guide to Numpy" (section 2.1 Data-Type descriptors)?
   Or incorporate the material directly here?


.. automodule:: numpy.doc.basics
