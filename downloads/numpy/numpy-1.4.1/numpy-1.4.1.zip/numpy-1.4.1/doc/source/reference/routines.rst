********
Routines
********

.. toctree::
   :maxdepth: 2

   routines.array-creation
   routines.array-manipulation
   routines.indexing
   routines.dtype
   routines.io
   routines.fft
   routines.linalg
   routines.random
   routines.sort
   routines.logic
   routines.bitwise
   routines.statistics
   routines.math
   routines.functional
   routines.poly
   routines.financial
   routines.set
   routines.window
   routines.err
   routines.ma
   routines.help
   routines.other
   routines.testing
   routines.emath
   routines.matlib
   routines.dual
   routines.numarray
   routines.oldnumeric
   routines.ctypeslib
   routines.char
