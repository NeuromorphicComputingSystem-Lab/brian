*************
Release Notes
*************

.. include:: ../release/1.5.1-notes.rst
