.. _structured_arrays:

***************************************
Structured arrays (aka "Record arrays")
***************************************

.. automodule:: numpy.doc.structured_arrays
