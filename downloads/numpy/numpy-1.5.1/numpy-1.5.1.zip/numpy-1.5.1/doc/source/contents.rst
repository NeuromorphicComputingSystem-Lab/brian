#####################
Numpy manual contents
#####################

.. toctree::

   user/index
   reference/index
   release
   about
   bugs
   license
   glossary
