"""

======
Jargon
======

Placeholder for computer science, engineering and other jargon.

"""
